<?php defined('SYSPATH') or die('No direct script access.');
                return array (
  '3.8.0' => 
  array (
    'codename' => 'Carnival',
    'released' => '2020-02-13',
    'blog' => '',
    'changelog' => 'https://github.com/yclas/yclas/compare/3.7.0...3.8.0',
    'issues' => 'https://github.com/yclas/yclas/milestone/44?closed=1',
    'download' => 'https://j.mp/yc_380',
  ),
  '3.7.0' => 
  array (
    'codename' => 'Malkoha',
    'released' => '2019-08-29',
    'blog' => '',
    'changelog' => 'https://github.com/yclas/yclas/compare/3.6.0...3.7.0',
    'issues' => 'https://github.com/yclas/yclas/milestone/43?closed=1',
    'download' => 'https://j.mp/yc_370',
  ),
  '3.6.0' => 
  array (
    'codename' => 'Cuckoo',
    'released' => '2019-02-05',
    'blog' => '',
    'changelog' => 'https://github.com/yclas/yclas/compare/3.5.0...3.6.0',
    'issues' => 'https://github.com/yclas/yclas/milestone/41?closed=1',
    'download' => 'https://j.mp/yc_360',
  ),
  '3.5.0' => 
  array (
    'codename' => 'Quetzal',
    'released' => '2018-07-18',
    'blog' => '',
    'changelog' => 'https://github.com/yclas/yclas/compare/3.4.0...3.5.0',
    'issues' => 'https://github.com/yclas/yclas/milestone/40?closed=1',
    'download' => 'https://j.mp/yc_350',
  ),
  '3.4.0' => 
  array (
    'codename' => 'Valentines',
    'released' => '2018-02-14',
    'blog' => '',
    'changelog' => 'https://github.com/yclas/yclas/compare/3.3.0...3.4.0',
    'issues' => 'https://github.com/yclas/yclas/milestone/39?closed=1',
    'download' => 'https://j.mp/yc_340',
  ),
  '3.3.0' => 
  array (
    'codename' => 'Barcelona',
    'released' => '2017-09-04',
    'blog' => '',
    'changelog' => 'https://github.com/yclas/yclas/compare/3.2.0...3.3.0',
    'issues' => 'https://github.com/yclas/yclas/milestone/38?closed=1',
    'download' => 'https://j.mp/yc_330',
  ),
  '3.2.0' => 
  array (
    'codename' => 'Vilnius',
    'released' => '2017-03-28',
    'blog' => '',
    'changelog' => 'https://github.com/yclas/yclas/compare/3.1.0...3.2.0',
    'issues' => 'https://github.com/yclas/yclas/milestone/37?closed=1',
    'download' => 'https://j.mp/yc_320',
  ),
  '3.1.0' => 
  array (
    'codename' => 'Riga',
    'released' => '2016-12-28',
    'blog' => '',
    'changelog' => 'https://github.com/yclas/yclas/compare/3.0.0...3.1.0',
    'issues' => 'https://github.com/yclas/yclas/milestone/36?closed=1',
    'download' => 'https://j.mp/yc_310',
  ),
  '3.0.0' => 
  array (
    'codename' => 'Kiev',
    'released' => '2016-11-10',
    'blog' => 'http://open-classifieds.com/2016/11/10/yclas-3/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.9.0...3.0.0',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A3.0.0+is%3Aclosed',
    'download' => 'https://j.mp/yc_300',
  ),
  '2.9.0' => 
  array (
    'codename' => 'Moscow',
    'released' => '2016-07-22',
    'blog' => 'http://open-classifieds.com/2016/07/22/open-classifieds-2-9-0/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.8.0...2.9.0',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A2.9.0+is%3Aclosed',
    'download' => 'https://j.mp/oc_290',
  ),
  '2.8.0' => 
  array (
    'codename' => 'Saigon',
    'released' => '2016-06-28',
    'blog' => 'http://open-classifieds.com/2016/06/28/open-classifieds-2-8-0/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.7.0...2.8.0',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A2.8.0+is%3Aclosed',
    'download' => 'https://j.mp/oc_280',
  ),
  '2.7.2' => 
  array (
    'codename' => 'Tlaloc2',
    'released' => '2016-05-25',
    'blog' => 'http://open-classifieds.com/2016/05/25/open-classifieds-2-7-2/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.7.1...2.7.2',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A2.7.2+is%3Aclosed',
    'download' => 'https://j.mp/oc_272',
  ),
  '2.7.1' => 
  array (
    'codename' => 'Tlaloc',
    'released' => '2016-05-10',
    'blog' => 'http://open-classifieds.com/2016/05/10/open-classifieds-2-7-1/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.7.0...2.7.1',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A2.7.1+is%3Aclosed',
    'download' => 'https://j.mp/oc_271',
  ),
  '2.7.0' => 
  array (
    'codename' => 'Taipei',
    'released' => '2016-03-11',
    'blog' => 'http://open-classifieds.com/2016/03/11/open-classifieds-2-7-0/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.6.1...2.7.0',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A2.7.0+is%3Aclosed',
    'download' => 'https://j.mp/oc_270',
  ),
  '2.6.1' => 
  array (
    'codename' => 'Taiwan',
    'released' => '2015-12-22',
    'blog' => 'http://open-classifieds.com/2015/12/22/open-classifieds-2-6-1/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.6.0...2.6.1',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A2.6.1+is%3Aclosed',
    'download' => 'http://j.mp/oc_261',
  ),
  '2.6.0' => 
  array (
    'codename' => 'Taipei',
    'released' => '2015-12-01',
    'blog' => 'http://open-classifieds.com/2015/12/01/open-classifieds-2-6-0/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.5.1...2.6.0',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A2.6.0+is%3Aclosed',
    'download' => 'http://j.mp/oc_260',
  ),
  '2.5.1' => 
  array (
    'codename' => 'Punta Cana',
    'released' => '2015-09-10',
    'blog' => 'http://open-classifieds.com/2015/09/10/open-classifieds-2-5-1/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.5.0...2.5.1',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A2.5.1+is%3Aclosed',
    'download' => 'http://j.mp/oc_251',
  ),
  '2.5.0' => 
  array (
    'codename' => 'Las Galeras',
    'released' => '2015-08-10',
    'blog' => 'http://open-classifieds.com/2015/08/10/open-classifieds-2-5-0/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.4.1...2.5.0',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A2.5.0+is%3Aclosed',
    'download' => 'http://j.mp/oc_250',
  ),
  '2.4.1' => 
  array (
    'codename' => 'Puerto Plata',
    'released' => '2015-05-19',
    'blog' => 'http://open-classifieds.com/2015/05/19/open-classifieds-2-4-1/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.4.0...2.4.1',
    'issues' => 'https://github.com/yclas/yclas/issues?q=milestone%3A2.4.1+is%3Aclosed',
    'download' => 'http://j.mp/oc_241',
  ),
  '2.4.0' => 
  array (
    'codename' => 'Samana',
    'released' => '2015-04-28',
    'blog' => 'http://open-classifieds.com/2015/04/28/open-classifieds-2-4-0/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.3.1...2.4.0',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=26&page=1&state=closed',
    'download' => 'http://j.mp/oc_240',
  ),
  '2.3.1' => 
  array (
    'codename' => 'Boca Chica',
    'released' => '2015-02-02',
    'blog' => 'http://open-classifieds.com/2015/02/02/open-classifieds-2-3-1/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.3.0...2.3.1',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=25&page=1&state=closed',
    'download' => 'http://j.mp/oc_231',
  ),
  '2.3.0' => 
  array (
    'codename' => 'Bayahibe',
    'released' => '2014-12-16',
    'blog' => 'http://open-classifieds.com/2014/12/16/open-classifieds-2-3-0/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.2.1...2.3.0',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=24&page=1&state=closed',
    'download' => 'http://j.mp/oc_230',
  ),
  '2.2.1' => 
  array (
    'codename' => 'Abroscopus',
    'released' => '2014-09-17',
    'blog' => 'http://open-classifieds.com/2014/09/17/open-classifieds-2-2-1/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.2.0...2.2.1',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=23&page=1&state=closed',
    'download' => 'http://j.mp/oc_221',
  ),
  '2.2.0' => 
  array (
    'codename' => 'Dryocopus',
    'released' => '2014-08-27',
    'blog' => 'http://open-classifieds.com/2014/08/27/open-classifieds-2-2-0/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.1.8.1...2.2.0',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=22&page=1&state=closed',
    'download' => 'http://j.mp/oc_220',
  ),
  '2.1.8.1' => 
  array (
    'codename' => 'Vila Olimpica',
    'released' => '2014-06-30',
    'blog' => 'http://open-classifieds.com/2014/06/30/open-classifieds-2-1-8-1/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.1.8...2.1.8.1',
    'issues' => 'http://open-classifieds.com/2014/06/30/open-classifieds-2-1-8-1/',
    'download' => 'http://j.mp/oc_2181',
  ),
  '2.1.8' => 
  array (
    'codename' => 'Barceloneta',
    'released' => '2014-05-29',
    'blog' => 'http://open-classifieds.com/2014/05/29/open-classifieds-2-1-8/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.1.7...2.1.8',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=21&page=1&state=closed',
    'download' => 'http://j.mp/oc_218',
  ),
  '2.1.7' => 
  array (
    'codename' => 'Ciutadella',
    'released' => '2014-05-19',
    'blog' => 'http://open-classifieds.com/2014/05/19/open-classifieds-2-1-7/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.1.6...2.1.7',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=20&page=1&state=closed',
    'download' => 'http://j.mp/oc_217',
  ),
  '2.1.6' => 
  array (
    'codename' => 'Llacuna',
    'released' => '2014-05-02',
    'blog' => 'http://open-classifieds.com/2014/05/02/open-classifieds-2-1-6/',
    'changelog' => 'https://github.com/yclas/yclas/compare/2.1.5...2.1.6',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=19&state=closed',
    'download' => 'http://j.mp/oc_216',
  ),
  '2.1.5' => 
  array (
    'codename' => 'Bogatell',
    'released' => '2014-05-01',
    'blog' => 'http://open-classifieds.com/2014/05/01/open-classifieds-2-1-5/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.1.5',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=19&state=closed',
    'download' => 'http://j.mp/oc_215',
  ),
  '2.1.4' => 
  array (
    'codename' => 'Budapest',
    'released' => '2014-03-26',
    'blog' => 'http://open-classifieds.com/2014/03/26/new-release-open-classifieds-2-1-4/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.1.4',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=17&state=closed',
    'download' => 'http://j.mp/oc_214',
  ),
  '2.1.3' => 
  array (
    'codename' => 'Nmemba',
    'released' => '2014-03-03',
    'blog' => 'http://open-classifieds.com/2014/03/03/new-release-2-1-3/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.1.3',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=16&state=closed',
    'download' => 'http://j.mp/oc_213',
  ),
  '2.1.2' => 
  array (
    'codename' => 'Paje',
    'released' => '2014-01-30',
    'blog' => 'http://open-classifieds.com/2014/01/30/new-release-open-classifieds-2-1-2/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.1.2',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=15&state=closed',
    'download' => 'http://j.mp/oc_212',
  ),
  '2.1.1' => 
  array (
    'codename' => 'Damascus',
    'released' => '2014-01-10',
    'blog' => 'http://open-classifieds.com/2014/01/10/new-release-open-classifieds-2-1-1/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.1.1',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=14&state=closed',
    'download' => 'http://j.mp/oc_211',
  ),
  '2.1' => 
  array (
    'codename' => 'Belgrade',
    'released' => '2013-12-26',
    'blog' => 'http://open-classifieds.com/2013/12/26/release-2-1/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.1',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=13&state=closed',
    'download' => 'http://j.mp/oc_210',
  ),
  '2.0.7' => 
  array (
    'codename' => 'Reoc',
    'released' => '2013-10-11',
    'blog' => 'http://open-classifieds.com/2013/10/11/new-release-2-0-7/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.0.7',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=12&state=closed',
    'download' => 'http://j.mp/oc_207',
  ),
  '2.0.6' => 
  array (
    'codename' => 'Reoc',
    'released' => '2013-09-05',
    'blog' => 'http://open-classifieds.com/2013/09/05/open-classifieds-2-0-6/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.0.6',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=11&state=closed',
    'download' => 'http://j.mp/oc_206',
  ),
  '2.0.5' => 
  array (
    'codename' => 'Reoc',
    'released' => '2013-08-06',
    'blog' => 'http://open-classifieds.com/2013/08/06/open-classifieds-2-0-5/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.0.5',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=10&state=closed',
  ),
  '2.0.4' => 
  array (
    'codename' => 'Reoc',
    'released' => '2013-07-09',
    'blog' => 'http://open-classifieds.com/2013/07/09/open-classifieds-2-0-4/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.0.4',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=9&state=closed',
  ),
  '2.0.3' => 
  array (
    'codename' => 'Reoc',
    'released' => '2013-07-02',
    'blog' => 'http://open-classifieds.com/2013/07/02/new-release-2-0-3/',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.0.3',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=8&state=closed',
  ),
  '2.0.2' => 
  array (
    'codename' => 'Reoc',
    'released' => '2013-06-14',
    'blog' => 'http://open-classifieds.com/2013/06/14/open-classifieds-2-0-2/ ',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.0.2',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=7&state=closed',
  ),
  '2.0.1' => 
  array (
    'codename' => 'Reoc',
    'released' => '2013-06-07',
    'blog' => 'http://open-classifieds.com/2013/06/07/open-classifieds-2-0-1/ ',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.0.1',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=6&state=closed',
  ),
  '2.0' => 
  array (
    'codename' => 'Reoc',
    'released' => '2013-05-31',
    'blog' => 'http://open-classifieds.com/2013/05/31/open-classifieds-2-0/ ',
    'changelog' => 'https://github.com/yclas/yclas/commits/2.0',
    'issues' => 'https://github.com/yclas/yclas/issues?milestone=5&state=closed',
  ),
);