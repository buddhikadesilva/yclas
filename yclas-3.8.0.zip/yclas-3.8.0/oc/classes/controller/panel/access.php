<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Panel_Access extends Auth_CrudAjax {

	/**
	 * @var $_orm_model ORM model name
	 */
	protected $_orm_model = 'access';

}
