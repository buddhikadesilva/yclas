<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Panel_Mylistings extends Controller_Panel_Myads {
}
