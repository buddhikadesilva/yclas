<?php

class Minion_Exception_InvalidTask extends Kohana_Minion_Exception_InvalidTask {}
