<?php

return [

	'modules' => [
		'minion' => [
			'enabled' => TRUE,
			'name' => 'Minion',
			'description' => 'Minion is a simple command line task runner',
			'copyright' => '&copy; 2009-2017 Kohana Team',
		]
	]

];
