<?php

class Pagination extends Kohana_Pagination {}
