<?php

abstract class Auth extends Kohana_Auth {}
