<?php

class Cache_Apc extends Kohana_Cache_Apc {}