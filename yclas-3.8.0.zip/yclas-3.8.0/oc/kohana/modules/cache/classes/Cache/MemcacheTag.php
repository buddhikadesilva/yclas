<?php

class Cache_MemcacheTag extends Kohana_Cache_MemcacheTag {}