<?php

class Cache_Sqlite extends Kohana_Cache_Sqlite {}