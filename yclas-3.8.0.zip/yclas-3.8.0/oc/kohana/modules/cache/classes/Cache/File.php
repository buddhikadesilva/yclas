<?php

class Cache_File extends Kohana_Cache_File {}