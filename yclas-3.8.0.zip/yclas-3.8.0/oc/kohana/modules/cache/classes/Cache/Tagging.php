<?php

interface Cache_Tagging extends Kohana_Cache_Tagging {}