<?php

class Cache_Exception extends Kohana_Cache_Exception {}