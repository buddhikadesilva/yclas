<?php

class Cache_Apcu extends Kohana_Cache_Apcu {}
