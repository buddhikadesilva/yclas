<?php

abstract class Image extends Kohana_Image {}
