<?php

class Encrypt_Engine_Mcrypt extends Kohana_Encrypt_Engine_Mcrypt {}
