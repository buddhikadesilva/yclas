<?php

class Encrypt_Engine_Openssl extends Kohana_Encrypt_Engine_Openssl {}
