<?php

abstract class Database_Query_Builder extends Kohana_Database_Query_Builder {}
