<?php

abstract class Database_Result extends Kohana_Database_Result {}
