<?php

class Database_Query extends Kohana_Database_Query {}
