<?php

class Database_PDO extends Kohana_Database_PDO {}
