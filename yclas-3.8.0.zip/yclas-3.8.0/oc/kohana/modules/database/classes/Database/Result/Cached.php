<?php

class Database_Result_Cached extends Kohana_Database_Result_Cached {}
