<?php

class Session_Database extends Kohana_Session_Database {}
