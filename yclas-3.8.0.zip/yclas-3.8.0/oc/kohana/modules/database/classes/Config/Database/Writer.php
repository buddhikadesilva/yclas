<?php

/**
 * Transparent extension for the Kohana_Config_Database_Writer class
 *
 * @package    Kohana/Database
 * @category   Configuration
 * @author     Kohana Team
 * @copyright  (c) Kohana Team
 * @license    https://koseven.ga/LICENSE.md
 */
class Config_Database_Writer extends Kohana_Config_Database_Writer
{
	
}
