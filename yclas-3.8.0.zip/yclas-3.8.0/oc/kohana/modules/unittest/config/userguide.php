<?php

return [
	'modules' => [
		'unittest' => [
			'enabled' => TRUE,
			'name' => 'Unittest',
			'description' => 'Unit testing module',
			'copyright' => '&copy; 2009-2017 Kohana Team',
		]
	]
];