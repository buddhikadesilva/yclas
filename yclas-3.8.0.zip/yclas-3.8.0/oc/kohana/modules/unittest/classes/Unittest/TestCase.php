<?php

abstract class Unittest_TestCase extends Kohana_Unittest_TestCase {}
