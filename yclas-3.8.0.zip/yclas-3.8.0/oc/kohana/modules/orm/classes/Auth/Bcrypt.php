<?php

class Auth_Bcrypt extends Kohana_Auth_Bcrypt {}