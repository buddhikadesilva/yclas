<?php

class ORM_Behavior_LocalBehavior extends Kohana_ORM_Behavior_LocalBehavior { }
